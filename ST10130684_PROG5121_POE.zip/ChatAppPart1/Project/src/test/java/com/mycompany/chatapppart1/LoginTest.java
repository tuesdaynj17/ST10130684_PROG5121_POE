/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 *
 * @author ST10130684
 */

public class LoginTest 
{
    //Calling the class LoginPage
    LoginPage log = new LoginPage();
    //Public method to test username with correct details
    @Test
    public void testCorrectUsername()
    {
         assertTrue(log.checkUserName("kyl_z"));
        
    }
    //Public method to test username with incorrect details
    @Test
    public void testIncorrectUsername()
    {
        assertFalse(log.checkUserName("kyle"));
    }
    
    //Public method to test password with correct details
    @Test
    public void testCorrectPassword()
    {
        assertTrue(log.checkPasswordComplexity("Ch&&sec@ke99!"));
    }
    
    //Public method to test password with incorrect details
    @Test
    public void testIncorrectPassword()
    {
        assertFalse(log.checkPasswordComplexity("password"));
    }
    
    //Public method to test cellphone with correct details
    @Test
    public void testCorrectCellphone()
    {
        assertTrue(log.checkCellPhoneNumber("+27715327367"));
    }
    
    //Public method to test cellphone with incorrect details
    @Test
    public void testIncorrectCellphone()
    {
        assertFalse(log.checkCellPhoneNumber("0715327367"));
    }
    
    //Public method to test login with correct details
    @Test
    public void testCorrectLogin()
    {
        log.registerUser("kyl_z", "Ch&&sec@ke99!", "0715327367");
        assertTrue(log.loginUser("kyl_z", "Ch&&sec@ke99!"));
    }
    
    //Public method to test login with incorrect details
    @Test
    public void testIncorrectLogin()
    {
        log.registerUser("kyle", "password", "+27715327367");
        assertFalse(log.loginUser("kyle", "password"));
    }
      
}
