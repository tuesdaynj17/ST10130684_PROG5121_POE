/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import org.json.JSONObject;
/**
 *
 * @author Student
 */
public class MessagesClass 
{
    //Declaring variables
    private String messageID;
    private String messageText;
    private String recipient;
    private String messageHash;
    private int numMessages;
    
    private static List<String> sentMessages = new ArrayList<>();
    private static List<String> disragardedMessages = new ArrayList<>();
    private static List<String> storedMessages = new ArrayList<>();
    private static List<String> messageHashes = new ArrayList<>();
    private static List<String> messageIDs = new ArrayList<>();

    public String getMessageID() 
    {
        return messageID;
    }

    public void setMessageID(String messageID) 
    {
        this.messageID = messageID;
    }

    public String getMessageText() 
    {
        return messageText;
    }

    public void setMessageText(String messageText) 
    {
        this.messageText = messageText;
    }

    public String getRecipient() 
    {
        return recipient;
    }

    public void setRecipient(String recipient) 
    {
        this.recipient = recipient;
    }

    public int getNumMessages() 
    {
        return numMessages;
    }

    public void setNumMessages(int numMessages) 
    {
        this.numMessages = numMessages;
    }
    
    //This method generates the message ID
    public void generateMessageID()
    {
        Random ran = new Random();
        StringBuilder id = new StringBuilder();
        
        for (int x = 0; x < 10; x++) 
        {
            id.append(ran.nextInt(10)); 
        }
        messageIDs.add(this.messageID = id.toString());
    }
    
    public String messageLength(String messageText)
    {
        if (messageText.length() > 250) 
        {
           int over = messageText.length() -250;
           System.out.println("Message is too long");
        }
        else
        {
           System.out.println("**Message accepted.**");
        }
        
        return messageText;
    }
    
    //This method checks the message recipient cell
    public String checkRecipientCell(String recipient)
    {
        if (recipient != null && recipient.startsWith("+27") 
                && recipient.length() == 12) 
        {
            return "Cellphone number is successfully captured.";
            
        }
        else
        {
            return "Cellphone number is incorrectly formatted.";
        }
    }
    
    //This method creates the message hash
    public String createMessageHash()
    {
        String[] words = messageText.split(" ");
        
        String firstWord = words[0].replaceAll("[^a-zA-Z]", "");
        String lastWord = words[words.length -1].replace("[^a-zA-Z]", "");
        
        messageHash = messageID.substring(0, 2) + ":" + numMessages + ":" 
                + (firstWord + lastWord).toUpperCase();
        
        return messageHash;
    }
    
    //This method stores messages
    public void storeMessage()
    {
        //messageHashes.add(createMessageHash());
        
        JSONObject obj = new JSONObject();
        obj.put("messageID", this.messageID);
        obj.put("recipient", this.recipient);
        obj.put("message", this.messageText);
        
        try(FileWriter fw = new FileWriter("message.json", true))
        {
            fw.write(obj.toString());
        }
        catch(IOException e)
        {
            System.out.println("Error has occured withstoring the info.");
        }
    }
    
    public String sentMessage()
    {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("""
                           What would you like to do with this message?
                           (1) Send Message.
                           (2) Disregard Message.
                           (3) Store Message to send later.
                           """);
        int options = scan.nextInt();
        
        
        
       switch (options)
       {
           case 1 : 
               return "Message seccussfully sent";
           case 2 : 
               return "Press 0 to delete the message";
           case 3 : 
               createMessageHash();
               return "Message seccussfully stored";
           default:
               return "Invalid option";
       }
    }   
}
