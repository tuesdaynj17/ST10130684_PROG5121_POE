/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

import java.util.Scanner;

/**
 *
 * @author ST10130684
 */
public class MainApp 
{
    //Declaring scanner class and LoginPage class
    Scanner scan = new Scanner(System.in);
    LoginPage log = new LoginPage();
    MessagesClass msg = new MessagesClass();
    
    //Method to prompt the user for registraction details
    public void inputRegistraction()
    {
        //Declaring variables
        String username, password, phone, response;
        
        //Prompting the user for information
        System.out.println("************REGISTRACTION SECTION************");
        
        while(true)
        {
            System.out.println("Enter a username: ");
            username = scan.nextLine();
            
            if (log.checkUserName(username)) 
            {
                System.out.println("Username succesfully captured.");
                break;
            }
            else
            {
                System.out.println("Invalid username. Must contain '_' "
                        + "and be <= 5 characters.");
            }
        }
        
        while(true)
        {
            System.out.println("Enter a password: ");
            password = scan.nextLine();
            
            if (log.checkPasswordComplexity(password)) 
            {
                System.out.println("Password successfully captured.");
                break;
            }
            else
            {
                System.out.println("Invalid Paasword must be 8+ char, include"
                        + " capital, number and a special character.");
            }
        }
        
        while(true)
        {
            System.out.println("Enter your SA phone number (+27...): ");
            phone = scan.nextLine();
            
            if (log.checkCellPhoneNumber(phone)) 
            {
                System.out.println("Cellphone captured successfully.");
                break;
            }
            else
            {
                System.out.println("Invalid phone number format.");
            }
        }
        
        //Call the registerUser method and store the message it returns
        response = log.registerUser(username, password, phone);
        
        //Shows the registraction message
        System.out.println(response);
    }
    
    //Method to prompt the user for login details
    public void inputLogin()
    {
        //Declaring variables
        String loginUsername, loginPassword, loginMessage;
        boolean loggedIn;
        
        //Prompting the user for information to login
        System.out.println("************LOGIN SECTION************");
        System.out.println("Enter a username: ");
        loginUsername = scan.nextLine();
        System.out.println("Enter a password: ");
        loginPassword = scan.nextLine();
        
        //Call loginUser to check if details match the stored ones
        loggedIn = log.loginUser(loginUsername, loginPassword);     
        
        //Print out the correct login message
        loginMessage = log.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
    }
    
    public void messagesMethodView()
    {
        boolean running = true;
        int option, messageNumber; //numMessages
        //String recipient, messageSent ;
        
        System.out.println("************WELCOME TO CHATAPP************");
        
        while(running)
        {
            System.out.println("""
                               
                               ************CHAT MENU************
                               (1) Send messages.
                               (2) Show recently sent messages.
                               (3) Quit
                               (4) Stored Messages""");
            option = scan.nextInt();
            
            switch(option)
            {
                case 1:
                    System.out.println("How many messages: ");
                    msg.setNumMessages(scan.nextInt());
                    
                    
                    for (int x = 0; x < msg.getNumMessages(); x++) 
                    {
                        messageNumber = x +1;
                        
                        System.out.println("Enter recipient number: ");
                        msg.setRecipient(scan.nextLine());
                        
                        scan.nextLine();
                        
                        System.out.println("Enter the message: ");
                        msg.setMessageText(scan.nextLine());
                        
                        msg.messageLength(msg.getMessageText());
                        
                    }
                    
                    msg.sentMessage();
                    
                    break;
                    
                case 2:
                    System.out.println("Coming soon...");
                    break;
                    
                case 3:
                    System.out.println("Goodbye!");
                    running = false;
                    break;
                    
                case 4:
                    
                    
                default:
                    System.out.println("Invalid option.");
            }
        }
        
        scan.close();
    }
}
