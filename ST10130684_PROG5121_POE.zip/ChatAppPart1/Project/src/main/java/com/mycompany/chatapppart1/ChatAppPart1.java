/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapppart1;

/**
 *
 * @author ST10130684
 */
public class ChatAppPart1 
{

    public static void main(String[] args) 
    {
        //Declaring the MainApp class and calling methods within
        MainApp app = new MainApp();
        app.inputRegistraction();
        app.inputLogin();
        app.messagesMethodView();
       
    }
}
